// Shared by the popup and MV3 service worker; no DOM dependencies.
globalThis.SuperKServer = {
  normalizeUrl(value) {
    let url;
    try { url = new URL(value.trim()); } catch { throw new Error('กรุณาระบุ URL ระบบ SuperK ให้ถูกต้อง'); }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
      throw new Error('ใช้ URL http:// หรือ https:// โดยไม่มีรหัสผ่าน query หรือ #');
    }
    return url.href.replace(/\/+$/, '');
  },

  async blobToBase64(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = '';
    for (let i = 0; i < bytes.length; i += 8192) {
      binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    }
    return btoa(binary);
  },

  parseResult(text) {
    const result = JSON.parse(text.replace(/```json/gi, '').replace(/```/g, '').trim());
    if (!result || !Array.isArray(result.bubbles) || result.bubbles.some(b =>
      !b || typeof b.t !== 'string' || !Array.isArray(b.box) || b.box.length !== 4 ||
      b.box.some(n => typeof n !== 'number' || !Number.isFinite(n) || n < 0 || n > 1000)
    )) throw new Error('ระบบแปลส่งตำแหน่งข้อความไม่ถูกต้อง กรุณาลองใหม่');
    return result;
  },

  splitGeminiKeys(raw) {
    return [...new Set(
      String(raw || '')
        .split(/[\s,;]+/)
        .map(key => key.trim())
        .filter(Boolean)
    )].slice(0, 10);
  },

  isPreviewModel(model) {
    const text = `${model?.id || ''} ${model?.displayName || ''} ${model?.description || ''}`.toLowerCase();
    return /(?:preview|experimental|\bexp\b)/.test(text);
  },

  async discoverGeminiRoutes(rawApiKeys, options = {}) {
    const keys = this.splitGeminiKeys(rawApiKeys);
    if (!keys.length) throw new Error('กรุณาใส่ Gemini API Key ก่อนใช้งาน');
    const modelPreference = options.modelPreference || 'auto';
    const allowPreview = options.allowPreview === true;
    const byModel = new Map();

    for (let keyIndex = 0; keyIndex < keys.length; keyIndex++) {
      const apiKey = keys[keyIndex];
      let pageToken = '';
      do {
        const url = new URL('https://generativelanguage.googleapis.com/v1beta/models');
        if (pageToken) url.searchParams.set('pageToken', pageToken);
        const response = await fetch(url.toString(), {
          method: 'GET',
          headers: { 'x-goog-api-key': apiKey, Accept: 'application/json' },
          signal: AbortSignal.timeout(15000),
        });
        if (!response.ok) {
          if (response.status === 401 || response.status === 403) break;
          throw new Error(`Gemini model discovery failed (HTTP ${response.status})`);
        }
        const data = await response.json();
        for (const item of Array.isArray(data?.models) ? data.models : []) {
          if (!Array.isArray(item?.supportedGenerationMethods) || !item.supportedGenerationMethods.includes('generateContent')) continue;
          const id = String(item.name || '').replace(/^models\//, '');
          if (!id || !id.startsWith('gemini-')) continue;
          const existing = byModel.get(id) || { id, displayName: item.displayName || id, description: item.description || '', keys: [] };
          existing.keys.push({ apiKey, keyIndex });
          byModel.set(id, existing);
        }
        pageToken = typeof data?.nextPageToken === 'string' ? data.nextPageToken : '';
      } while (pageToken);
    }

    if (modelPreference !== 'auto') {
      const selected = byModel.get(modelPreference);
      if (!selected) throw new Error(`โมเดล ${modelPreference} ไม่พร้อมใช้งานกับ API Key ที่ตั้งไว้`);
      return selected.keys.map(key => ({ model: modelPreference, ...key }));
    }

    const models = [...byModel.values()].filter(model => allowPreview || !this.isPreviewModel(model));
    if (!models.length) throw new Error('ไม่พบ Gemini model ที่รองรับ generateContent สำหรับ API Key นี้');
    return models.flatMap(model => model.keys.map(key => ({ model: model.id, ...key })));
  },

  async reviewRequest(url, init, settings) {
    const headers = {'Content-Type':'application/json'};
    if (settings.pairingToken) headers.Authorization = `Bearer ${settings.pairingToken}`;
    try { return await fetch(`${this.normalizeUrl(settings.serverUrl)}/api/translation-review`, {...init, headers,
      body:JSON.stringify({...JSON.parse(init.body),apiKey:settings.apiKey || '',modelPreference:settings.modelPreference,allowPreview:settings.allowPreviewModels===true})});
    } catch (error) {
      if (settings.translationMode !== 'direct' || init.signal?.aborted) throw error;
      const payload=JSON.parse(init.body);
      const routes=await this.discoverGeminiRoutes(settings.apiKey,{modelPreference:settings.modelPreference||'auto',allowPreview:settings.allowPreviewModels===true});
      const route=routes[0]; if (!route) throw error;
      const response=await fetch('https://generativelanguage.googleapis.com/v1beta/interactions',{
        method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':route.apiKey},signal:init.signal,
        body:JSON.stringify({model:route.model,store:false,input:SuperKPolicy.buildQualityReviewPrompt(payload.items,payload.targetLang,payload.glossary||[])})});
      if (!response.ok) return response;
      const data=await response.json();
      const text=(data.steps||[]).filter(step=>step.type==='model_output').flatMap(step=>step.content||[]).filter(part=>part.type==='text').map(part=>part.text).join('');
      return new Response(JSON.stringify(JSON.parse(text.replace(/```json|```/gi,'').trim())),{status:200,headers:{'Content-Type':'application/json'}});
    }
  },

  async translate(image, settings) {
    if (!globalThis.SuperKPolicy?.createPageTargetIdentity(settings.targetLang)) throw new Error('Choose a supported target writing system');
    const base = this.normalizeUrl(settings.serverUrl);
    let response;
    const headers = { 'Content-Type': 'application/json' };
    if (settings.pairingToken) {
      headers['Authorization'] = `Bearer ${settings.pairingToken}`;
      headers['x-superk-pairing-token'] = settings.pairingToken;
    }
    try {
      response = await fetch(`${base}/api/translate`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          imageBase64: image.base64, mimeType: image.mimeType,
          targetLang: settings.targetLang, sourceLang: settings.sourceLang,
          modelPreference: settings.modelPreference,
          apiKey: settings.geminiApiKey || settings.apiKey || '',
          allowPreview: settings.allowPreviewModels === true,
        }),
        signal: AbortSignal.timeout(70000),
      });
    } catch (cause) {
      const timedOut = cause?.name === 'TimeoutError' || cause?.name === 'AbortError';
      const error = new Error(timedOut
        ? 'ระบบ SuperK แปลภาพเกินเวลาที่กำหนด กรุณาลองใหม่'
        : 'เชื่อมต่อระบบแปลไม่ได้ ตรวจสอบ URL และเปิดระบบ SuperK ไว้');
      error.code = timedOut ? 'SUPERK_SERVER_TIMEOUT' : 'SUPERK_SERVER_UNREACHABLE';
      throw error;
    }
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      const error = new Error(data?.error || `ระบบแปลตอบกลับ HTTP ${response.status}`);
      error.code = data?.code || 'SUPERK_TRANSLATION_ERROR';
      error.status = response.status;
      error.retryAfterMs = data?.retryAfterMs;
      error.nextRetryAt = data?.nextRetryAt;
      throw error;
    }
    if (typeof data?.text !== 'string') throw new Error('URL นี้ไม่ได้ตอบกลับจาก API แปลของ SuperK');
    return this.parseResult(data.text);
  },

  _cachedSettingsByUrl: new Map(),
  CACHE_TTL_MS: 30000,

  async fetchSettings(rawServerUrl, pairingToken) {
    const now = Date.now();
    let serverUrl = 'http://127.0.0.1:3000';
    try {
      serverUrl = this.normalizeUrl(rawServerUrl || 'http://127.0.0.1:3000');
    } catch {
      // Keep default
    }

    const cachedEntry = this._cachedSettingsByUrl?.get(serverUrl);
    if (cachedEntry && (now - cachedEntry.timestamp) < this.CACHE_TTL_MS) {
      return { ...cachedEntry.settings, isOfflineFallback: false };
    }

    const defaultFallback = {
      geminiApiKey: '',
      modelPreference: 'auto',
      // Compatibility field only; dynamic discovery is the source of truth.
      modelHierarchy: [],
      allowPreviewModels: false,
      glossary: [],
      textStyle: {
        fontFamily: 'Itim, sans-serif',
        fontSizeMultiplier: 1.0,
        textColor: '#000000',
        textOutline: '#FFFFFF',
      },
      ocrServiceUrl: 'http://127.0.0.1:8765',
      targetLang: 'Thai',
      sourceLang: 'auto',
      cleanMode: 'inpainting',
    };

    const storageKey = `superk_cached_settings_${encodeURIComponent(serverUrl)}`;

    try {
      const headers = { Accept: 'application/json' };
      if (pairingToken) {
        headers['Authorization'] = `Bearer ${pairingToken}`;
        headers['x-superk-pairing-token'] = pairingToken;
      }
      const response = await fetch(`${serverUrl}/api/extension/settings`, {
        method: 'GET',
        headers,
        signal: AbortSignal.timeout(5000),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const data = await response.json();
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid settings JSON');
      }

      const mergedSettings = { ...defaultFallback, ...data };
      if (!this._cachedSettingsByUrl) {
        this._cachedSettingsByUrl = new Map();
      }
      this._cachedSettingsByUrl.set(serverUrl, { settings: mergedSettings, timestamp: now });

      if (typeof chrome !== 'undefined' && chrome?.storage?.local?.set) {
        await chrome.storage.local.set({ [storageKey]: mergedSettings }).catch(() => {});
      }

      return { ...mergedSettings, isOfflineFallback: false };
    } catch {
      if (typeof chrome !== 'undefined' && chrome?.storage?.local?.get) {
        try {
          const stored = await chrome.storage.local.get(storageKey);
          if (stored?.[storageKey]) {
            return {
              ...defaultFallback,
              ...stored[storageKey],
              isOfflineFallback: true,
            };
          }
        } catch {
          // Ignore
        }
      }

      return {
        ...defaultFallback,
        isOfflineFallback: true,
      };
    }
  },

  async inpaintImage(image, settings) {
    let base = 'http://127.0.0.1:3000';
    try {
      base = this.normalizeUrl(settings?.serverUrl || 'http://127.0.0.1:3000');
    } catch {
      // Keep default
    }

    const binary = atob(image.base64);
    const array = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) array[i] = binary.charCodeAt(i);
    const blob = new Blob([array], { type: image.mimeType || 'image/png' });

    const formData = new FormData();
    formData.append('image', blob, 'manga.png');
    formData.append('cleaning_mode', 'all-text');

    let postRes;
    try {
      postRes = await fetch(`${base}/api/clean/v1/jobs`, {
        method: 'POST',
        body: formData,
        signal: AbortSignal.timeout(30000),
      });
    } catch {
      throw new Error('ไม่สามารถเชื่อมต่อ Inpainting Engine ได้ กรุณาเปิดระบบ SuperK ไว้');
    }

    if (!postRes.ok) {
      throw new Error(`Inpainting Engine ตอบกลับข้อผิดพลาด (HTTP ${postRes.status})`);
    }

    const jobData = await postRes.json();
    const jobId = jobData.job_id || jobData.jobId;
    if (!jobId) {
      throw new Error('ไม่ได้รับ Job ID จากระบบคลีน');
    }

    const startTime = Date.now();
    let status = jobData.status;
    while (status === 'queued' || status === 'running' || status === 'detecting' || status === 'cleaning') {
      if (Date.now() - startTime > 120000) {
        throw new Error('Inpainting หมดเวลา (Timeout)');
      }
      await new Promise(r => setTimeout(r, 500));
      const pollRes = await fetch(`${base}/api/clean/v1/jobs/${encodeURIComponent(jobId)}`, {
        signal: AbortSignal.timeout(10000),
      });
      if (!pollRes.ok) throw new Error('เกิดข้อผิดพลาดระหว่างตรวจสอบสถานะ Inpainting');
      const pollData = await pollRes.json();
      status = pollData.status;
      if (status === 'failed' || status === 'error') {
        throw new Error(pollData.error || 'การลบข้อความต้นฉบับ (Inpainting) ล้มเหลว');
      }
    }

    const resultRes = await fetch(`${base}/api/clean/v1/jobs/${encodeURIComponent(jobId)}/result`, {
      signal: AbortSignal.timeout(30000),
    });
    if (!resultRes.ok) throw new Error('ไม่สามารถดาวน์โหลดผลลัพธ์ภาพที่คลีนแล้วได้');
    const resultData = await resultRes.json();

    const cleanAssetPath = resultData.clean_asset || resultData.cleanAsset;
    let cleanImageBase64 = '';
    if (cleanAssetPath) {
      let assetUrl = cleanAssetPath;
      if (!assetUrl.startsWith('http')) {
        const cleanPathNormalized = cleanAssetPath.startsWith('/api/clean')
          ? cleanAssetPath
          : `/api/clean${cleanAssetPath.startsWith('/') ? '' : '/'}${cleanAssetPath}`;
        assetUrl = `${base}${cleanPathNormalized}`;
      }
      const assetRes = await fetch(assetUrl, { signal: AbortSignal.timeout(30000) });
      if (!assetRes.ok) {
        throw new Error(`ไม่สามารถดาวน์โหลดไฟล์ภาพที่ลบข้อความแล้วได้ (HTTP ${assetRes.status})`);
      }
      const assetBlob = await assetRes.blob();
      cleanImageBase64 = await this.blobToBase64(assetBlob);
    }

    if (!cleanImageBase64) {
      throw new Error('ไม่ได้รับข้อมูลภาพที่ลบข้อความแล้ว (cleanImageBase64) จากระบบ Inpainting');
    }

    return {
      jobId,
      cleanImageBase64,
      cleanMimeType: 'image/png',
    };
  },

  MONOCHROME_THRESHOLDS: {
    MAX_SAMPLES: 20000,
    MIN_ALPHA: 32,
    CHROMA_THRESHOLD: 18,
    SATURATION_THRESHOLD: 0.08,
    STRONG_CHROMA_THRESHOLD: 35,
    STRONG_SATURATION_THRESHOLD: 0.18,
    MAX_CHROMATIC_RATIO: 0.02,
    MAX_STRONG_CHROMATIC_RATIO: 0.005,
  },

  classifyMonochromeRgba(rgba, width, height) {
    const totalPixels = width * height;
    if (totalPixels <= 0 || rgba.length < totalPixels * 4) {
      return { isMonochromePage: false, monochromeConfidence: 0 };
    }
    const stride = Math.max(1, Math.ceil(totalPixels / this.MONOCHROME_THRESHOLDS.MAX_SAMPLES));
    let sampledPixelCount = 0;
    let chromaticPixelCount = 0;
    let strongChromaticPixelCount = 0;

    for (let i = 0; i < totalPixels; i += stride) {
      const offset = i * 4;
      const a = rgba[offset + 3];
      if (a < this.MONOCHROME_THRESHOLDS.MIN_ALPHA) continue;

      const r = rgba[offset];
      const g = rgba[offset + 1];
      const b = rgba[offset + 2];
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const chroma = max - min;
      const saturation = max > 0 ? chroma / max : 0;

      sampledPixelCount++;
      if (chroma >= this.MONOCHROME_THRESHOLDS.CHROMA_THRESHOLD && saturation >= this.MONOCHROME_THRESHOLDS.SATURATION_THRESHOLD) {
        chromaticPixelCount++;
      }
      if (chroma >= this.MONOCHROME_THRESHOLDS.STRONG_CHROMA_THRESHOLD && saturation >= this.MONOCHROME_THRESHOLDS.STRONG_SATURATION_THRESHOLD) {
        strongChromaticPixelCount++;
      }
    }

    if (sampledPixelCount === 0) {
      return { isMonochromePage: false, monochromeConfidence: 0 };
    }

    const chromaticRatio = chromaticPixelCount / sampledPixelCount;
    const strongRatio = strongChromaticPixelCount / sampledPixelCount;
    const isMonochrome =
      chromaticRatio <= this.MONOCHROME_THRESHOLDS.MAX_CHROMATIC_RATIO &&
      strongRatio <= this.MONOCHROME_THRESHOLDS.MAX_STRONG_CHROMATIC_RATIO;

    const penaltyRatio = Math.max(
      chromaticRatio / this.MONOCHROME_THRESHOLDS.MAX_CHROMATIC_RATIO,
      strongRatio / this.MONOCHROME_THRESHOLDS.MAX_STRONG_CHROMATIC_RATIO,
    );
    const confidence = Math.max(0, Math.min(1, 1 - penaltyRatio * 0.5));

    return {
      isMonochromePage: isMonochrome,
      monochromeConfidence: Number(confidence.toFixed(4)),
    };
  },

  sampleBubbleLuminance(ctx, bubbles, canvasWidth, canvasHeight) {
    const mean = {};
    const samples = {};
    if (!ctx || !Array.isArray(bubbles) || canvasWidth <= 0 || canvasHeight <= 0) {
      return { mean, samples };
    }
    bubbles.forEach((b, idx) => {
      if (!b || !Array.isArray(b.box) || b.box.length < 4) return;
      const [ymin, xmin, ymax, xmax] = b.box;
      const x = Math.floor((Math.min(xmin, xmax) / 1000) * canvasWidth);
      const y = Math.floor((Math.min(ymin, ymax) / 1000) * canvasHeight);
      const w = Math.max(1, Math.ceil((Math.abs(xmax - xmin) / 1000) * canvasWidth));
      const h = Math.max(1, Math.ceil((Math.abs(ymax - ymin) / 1000) * canvasHeight));

      try {
        const data = ctx.getImageData(x, y, w, h).data;
        const pixelCount = Math.max(1, Math.floor(data.length / 4));
        const sampleStep = Math.max(1, Math.ceil(pixelCount / 16));
        const regionSamples = [];
        let sumLum = 0;
        let count = 0;
        let pixelIndex = 0;
        for (let p = 0; p < data.length; p += 4, pixelIndex++) {
          if (data[p + 3] < 32) continue;
          const lum = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2];
          sumLum += lum;
          count++;
          if (pixelIndex % sampleStep === 0 && regionSamples.length < 16) {
            regionSamples.push(Math.round(lum));
          }
        }
        if (count > 0) {
          mean[idx] = Math.round(sumLum / count);
          if (regionSamples.length === 0) {
            regionSamples.push(mean[idx]);
          }
          samples[idx] = regionSamples;
        }
      } catch {}
    });
    return { mean, samples };
  },

  async analyzeImageStyle(base64, mimeType, bubbles) {
    try {
      if (typeof createImageBitmap === 'undefined') {
        return {
          pageStyle: { isMonochromePage: false, monochromeConfidence: 0 },
          bubbleBackgroundLuminance: {},
          bubbleBackgroundLuminanceSamples: {},
        };
      }
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: mimeType || 'image/png' });
      const bitmap = await createImageBitmap(blob);
      const scale = Math.min(1, 512 / Math.max(bitmap.width, bitmap.height));
      const width = Math.max(1, Math.round(bitmap.width * scale));
      const height = Math.max(1, Math.round(bitmap.height * scale));

      let ctx = null;
      let rgba = null;
      if (typeof OffscreenCanvas !== 'undefined') {
        const canvas = new OffscreenCanvas(width, height);
        ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(bitmap, 0, 0, width, height);
          rgba = ctx.getImageData(0, 0, width, height).data;
        }
      } else if (typeof document !== 'undefined') {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(bitmap, 0, 0, width, height);
          rgba = ctx.getImageData(0, 0, width, height).data;
        }
      }

      if (!rgba || !ctx) {
        return {
          pageStyle: { isMonochromePage: false, monochromeConfidence: 0 },
          bubbleBackgroundLuminance: {},
          bubbleBackgroundLuminanceSamples: {},
        };
      }

      const pageStyle = this.classifyMonochromeRgba(rgba, width, height);
      const bubbleEvidence = this.sampleBubbleLuminance(ctx, bubbles, width, height);
      return {
        pageStyle,
        bubbleBackgroundLuminance: bubbleEvidence.mean,
        bubbleBackgroundLuminanceSamples: bubbleEvidence.samples,
      };
    } catch {
      return {
        pageStyle: { isMonochromePage: false, monochromeConfidence: 0 },
        bubbleBackgroundLuminance: {},
        bubbleBackgroundLuminanceSamples: {},
      };
    }
  },
};

// The pairing token is a local secret: it must not live in
// chrome.storage.sync (it would sync to the user's Google profile, and sync
// quota churn can silently drop it). Reads prefer chrome.storage.local and
// migrate any token found in sync over to local, scrubbing it from sync.
// Every storage access is defensive — the helper must keep working in
// contexts where sync or local is unavailable.
async function loadExtensionSettings(defaults) {
  const fallback = { ...defaults };
  let syncStored = fallback;
  try {
    syncStored = (await chrome.storage?.sync?.get?.(defaults)) || fallback;
  } catch {
    syncStored = fallback;
  }
  let localToken = '';
  try {
    const localStored = (await chrome.storage?.local?.get?.({ pairingToken: '' })) || {};
    localToken = typeof localStored.pairingToken === 'string' ? localStored.pairingToken : '';
  } catch {
    localToken = '';
  }
  const syncToken = typeof syncStored.pairingToken === 'string' ? syncStored.pairingToken : '';
  if (syncToken && !localToken) {
    try {
      await chrome.storage?.local?.set?.({ pairingToken: syncToken });
      await chrome.storage?.sync?.remove?.('pairingToken');
    } catch {
      // Best-effort migration; the merged read below still returns the token.
    }
  }
  return { ...syncStored, pairingToken: localToken || syncToken };
}
