(() => {
if (globalThis.__superKLoaded) return;
globalThis.__superKLoaded = true;

// SuperK Manga Translator - Content Script

let activeOverlays = new Map(); // Key: imgUrl or imgElement

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "TRANSLATION_START") {
    handleTranslationStart(message.imageUrl);
  } else if (message.action === "TRANSLATION_SUCCESS") {
    handleTranslationSuccess(
      message.imageUrl,
      message.bubbles,
      message.cleanMode,
      message.cleanImageBase64,
      message.textStyle,
      message.pageStyle, message
    );
  } else if (message.action === "TRANSLATION_REVIEW_REQUIRED") {
    const payload = message.payload || {};
    const bubbles = payload.bubbles || [];
    if (bubbles.length > 0) {
      removeExistingLoadingScrim(message.imageUrl || payload.pageUrl);
      const img = findImageElement(message.imageUrl || payload.pageUrl);
      if (img) removeExistingBadge(img);
      renderTranslationOverlay(
        message.imageUrl || payload.pageUrl,
        bubbles,
        payload.cleanMode || 'inpainting',
        payload.cleanUrl || null,
        payload.textStyle,
        payload.pageStyle,
        payload
      );
    } else {
      handleTranslationError(message.imageUrl,'ตรวจจากต้นฉบับใน SuperK ก่อนอ่านคำแปล');
      const badge=document.getElementById(`superk-badge-${hashCode(message.imageUrl)}`);
      if (badge) {
        const button=document.createElement('button');button.textContent='ตรวจจากต้นฉบับใน SuperK';
        button.onclick=()=>chrome.runtime.sendMessage({action:'OPEN_EDITOR',payload:{...message.payload,originUrl:window.location.href}});
        badge.append(button);
      }
    }
  } else if (message.action === "TRANSLATION_ERROR") {
    handleTranslationError(message.imageUrl, message.error);
  } else if (message.action === "UPDATE_OVERLAY" && message.pageUrl) {
    handlePublishedUpdate(
      message.pageUrl,
      message.bubbles,
      message.cleanUrl,
      message.textStyle, message
    );
  }
});

// Helper: Find target image element on page by URL or context
function findImageElement(imageUrl) {
  const images = Array.from(document.querySelectorAll('img'));
  // Try exact match
  let target = images.find(img => img.src === imageUrl || img.currentSrc === imageUrl);
  if (target) return target;
  
  // Try matching filename or substring
  const urlFilename = imageUrl.split('/').pop().split('?')[0];
  if (urlFilename && urlFilename.length > 5) {
    target = images.find(img => img.src.includes(urlFilename));
    if (target) return target;
  }
  return null;
}

// 1. Handle Translation Start (Show Centered Loading Scrim Overlay)
function createLoadingScrim(img, imageUrl) {
  removeExistingLoadingScrim(imageUrl);

  const imgRect = img.getBoundingClientRect();
  const win = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : null);
  const scrollX = win ? (win.scrollX || win.pageXOffset || 0) : 0;
  const scrollY = win ? (win.scrollY || win.pageYOffset || 0) : 0;

  const container = document.createElement('div');
  container.className = 'superk-loading-scrim-container';
  container.dataset.superkLoadingFor = hashCode(imageUrl);

  const isCompact = imgRect.width < 180 || imgRect.height < 180;
  if (isCompact) {
    container.classList.add('superk-compact');
  }

  container.style.cssText = `
    position: absolute;
    top: ${imgRect.top + scrollY}px;
    left: ${imgRect.left + scrollX}px;
    width: ${imgRect.width}px;
    height: ${imgRect.height}px;
    pointer-events: none;
    z-index: 99998;
    overflow: hidden;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
  `;

  const scrim = document.createElement('div');
  scrim.className = 'superk-loading-scrim';

  const card = document.createElement('div');
  card.className = 'superk-loading-card';
  card.innerHTML = `
    <div class="superk-loading-emblem-wrap">
      <div class="superk-loading-ring"></div>
      <svg class="superk-loading-logo" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="#38bdf8"/>
      </svg>
    </div>
    <span class="superk-loading-text">SuperK กำลังแปลภาพนี้...</span>
  `;

  container.appendChild(scrim);
  container.appendChild(card);
  document.body.appendChild(container);

  const updateLoadingPosition = () => {
    if (!document.body.contains(container)) {
      win?.removeEventListener?.('resize', updateLoadingPosition);
      return;
    }
    const newRect = img.getBoundingClientRect();
    const newScrollX = win ? (win.scrollX || win.pageXOffset || 0) : 0;
    const newScrollY = win ? (win.scrollY || win.pageYOffset || 0) : 0;
    container.style.top = `${newRect.top + newScrollY}px`;
    container.style.left = `${newRect.left + newScrollX}px`;
    container.style.width = `${newRect.width}px`;
    container.style.height = `${newRect.height}px`;
  };
  win?.addEventListener?.('resize', updateLoadingPosition);
  // Deterministic teardown: removing the scrim must also drop its resize
  // listener, otherwise every translation leaks one until the next resize.
  container.__superkScrimDispose = () => {
    win?.removeEventListener?.('resize', updateLoadingPosition);
  };

  return container;
}

function removeExistingLoadingScrim(imageUrl) {
  const hash = hashCode(imageUrl);
  const existing = document.querySelectorAll(`.superk-loading-scrim-container[data-superk-loading-for="${hash}"]`);
  existing.forEach(el => {
    el.__superkScrimDispose?.();
    el.remove();
  });
}

function handleTranslationStart(imageUrl) {
  const img = findImageElement(imageUrl);
  if (!img) return;

  removeExistingBadge(img);
  removeExistingLoadingScrim(imageUrl);
  createLoadingScrim(img, imageUrl);
}

// 2. Handle Translation Success (Render Text Overlay)
function handleTranslationSuccess(imageUrl, bubbles, cleanMode, cleanImageBase64, textStyle, pageStyle, evidence) {
  const output = globalThis.SuperKPolicy?.inspectExtensionOutput ? SuperKPolicy.inspectExtensionOutput({...evidence,bubbles}) : { status: 'eligible' };
  if (output && output.status !== "eligible") {
    if (output.reasons?.includes("script-violation") || output.pointIssues?.length > 0) {
      handleTranslationError(imageUrl,"Saved translation needs current source-backed review in SuperK"); return;
    }
  }
  renderTranslationOverlay(imageUrl, bubbles, cleanMode, cleanImageBase64, textStyle, pageStyle, evidence);
}

function renderTranslationOverlay(imageUrl, bubbles, cleanMode, cleanImageBase64, textStyle, pageStyle, evidence) {
  const img = findImageElement(imageUrl);
  if (!img) return;

  removeExistingBadge(img);
  removeExistingLoadingScrim(imageUrl);

  if (!bubbles || bubbles.length === 0) {
    showErrorBadge(img, "ไม่พบข้อความในภาพนี้");
    return;
  }

  // Remove any previous overlay for this image
  const oldOverlay = document.querySelector(`.superk-overlay-container[data-superk-for="${hashCode(imageUrl)}"]`);
  if (oldOverlay) oldOverlay.remove();

  // Get actual rendered position and size of the image on screen
  const imgRect = img.getBoundingClientRect();
  const scrollX = window.scrollX || window.pageXOffset;
  const scrollY = window.scrollY || window.pageYOffset;

  // Create overlay container that exactly matches image position using absolute positioning in the document
  const overlayContainer = document.createElement('div');
  overlayContainer.className = 'superk-overlay-container';
  overlayContainer.dataset.superkFor = hashCode(imageUrl);
  overlayContainer.style.cssText = `
    position: absolute;
    top: ${imgRect.top + scrollY}px;
    left: ${imgRect.left + scrollX}px;
    width: ${imgRect.width}px;
    height: ${imgRect.height}px;
    pointer-events: none;
    z-index: 99999;
    font-family: ${textStyle?.fontFamily || "'Itim', 'FC Subject', sans-serif"};
    overflow: hidden;
  `;

  const layer = document.createElement('div');
  layer.style.cssText = `position:absolute;top:0;left:0;width:${imgRect.width}px;height:${imgRect.height}px;transform-origin:top left;pointer-events:none`;
  overlayContainer.appendChild(layer);

  // Calculate actual rendered image dimensions in case of object-fit: contain
  const objectFit = window.getComputedStyle(img).objectFit;
  let renderW = imgRect.width;
  let renderH = imgRect.height;
  let offsetX = 0;
  let offsetY = 0;

  if (img.naturalWidth && img.naturalHeight && (objectFit === 'contain' || objectFit === 'scale-down')) {
    const imgRatio = img.naturalWidth / img.naturalHeight;
    const boxRatio = imgRect.width / imgRect.height;
    if (imgRatio > boxRatio) {
      renderW = imgRect.width;
      renderH = imgRect.width / imgRatio;
      offsetY = (imgRect.height - renderH) / 2;
    } else {
      renderH = imgRect.height;
      renderW = imgRect.height * imgRatio;
      offsetX = (imgRect.width - renderW) / 2;
    }
  }

  // 1. Inpainting clean background or legacy white mask canvas
  if (cleanImageBase64) {
    const cleanImg = document.createElement('img');
    cleanImg.className = 'superk-clean-image';
    cleanImg.src = (cleanImageBase64.startsWith('data:') || cleanImageBase64.startsWith('http://') || cleanImageBase64.startsWith('https://'))
      ? cleanImageBase64
      : `data:image/png;base64,${cleanImageBase64}`;
    cleanImg.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: ${objectFit || 'fill'};
      pointer-events: none;
      z-index: 1;
    `;
    layer.appendChild(cleanImg);
  } else if (cleanMode !== 'stroke') {
    const cleanCanvas = document.createElement('canvas');
    cleanCanvas.className = 'superk-clean-canvas';
    cleanCanvas.width = Math.round(imgRect.width);
    cleanCanvas.height = Math.round(imgRect.height);
    cleanCanvas.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 1;
    `;
    const cctx = cleanCanvas.getContext ? cleanCanvas.getContext('2d') : null;

    if (cctx) {
      bubbles.forEach(b => {
        if (!b.box || b.box.length !== 4) return;
        let rawYmin = Math.min(b.box[0], b.box[2]);
        let rawXmin = Math.min(b.box[1], b.box[3]);
        let rawYmax = Math.max(b.box[0], b.box[2]);
        let rawXmax = Math.max(b.box[1], b.box[3]);

        const x = offsetX + (rawXmin / 1000) * renderW;
        const y = offsetY + (rawYmin / 1000) * renderH;
        const w = ((rawXmax - rawXmin) / 1000) * renderW;
        const h = ((rawYmax - rawYmin) / 1000) * renderH;

        const padX = Math.max(4, Math.round(w * 0.06));
        const padY = Math.max(6, Math.round(h * 0.12));
        const mx = Math.max(0, x - padX);
        const my = Math.max(0, y - padY);
        const mw = Math.min(renderW - mx, w + padX * 2);
        const mh = Math.min(renderH - my, h + padY * 2);

        const radius = Math.min(8, mw / 4, mh / 4);
        const bgLum = b.styleProfile?.backgroundLuminance;
        cctx.fillStyle = (typeof bgLum === 'number' && bgLum < 0.25) ? '#171717' : '#ffffff';
        cctx.beginPath();
        cctx.moveTo(mx + radius, my);
        cctx.lineTo(mx + mw - radius, my);
        cctx.quadraticCurveTo(mx + mw, my, mx + mw, my + radius);
        cctx.lineTo(mx + mw, my + mh - radius);
        cctx.quadraticCurveTo(mx + mw, my + mh, mx + mw - radius, my + mh);
        cctx.lineTo(mx + radius, my + mh);
        cctx.quadraticCurveTo(mx, my + mh, mx, my + mh - radius);
        cctx.lineTo(mx, my + radius);
        cctx.quadraticCurveTo(mx, my, mx + radius, my);
        cctx.closePath();
        cctx.fill();
      });
    }

    layer.appendChild(cleanCanvas);
  }

function wrapTextAdaptive(text, safeW, safeH, fs, fontFamily, isOval) {
  let words = [];
  if (typeof Intl !== 'undefined' && Intl.Segmenter) {
    try {
      const segmenter = new Intl.Segmenter('th', { granularity: 'word' });
      words = Array.from(segmenter.segment(text)).map(s => s.segment);
    } catch {
      words = text.split(/\s+/);
    }
  } else {
    words = text.split(/\s+/);
  }

  const tempCanvas = typeof document !== 'undefined' ? document.createElement('canvas') : null;
  const tempCtx = tempCanvas ? tempCanvas.getContext('2d') : null;
  const measure = (str) => {
    if (tempCtx && typeof tempCtx.measureText === 'function') {
      tempCtx.font = `bold ${fs}px ${fontFamily}`;
      const m = tempCtx.measureText(str);
      if (m && typeof m.width === 'number') return m.width;
    }
    return str.length * (fs * 0.6);
  };

  const lineH = fs * 1.30;
  const estLines = Math.max(1, Math.round(safeH / lineH));
  const getLineMaxW = (lineIdx, totalLines) => {
    if (!isOval || totalLines <= 1) return safeW;
    const v = ((lineIdx + 0.5) / totalLines - 0.5) * 2;
    const chord = Math.sqrt(Math.max(0.2, 1 - v * v));
    return safeW * chord * 0.95;
  };

  let best = [text];
  for (let tryLines = Math.max(1, estLines - 1); tryLines <= estLines + 2; tryLines++) {
    const lines = [];
    let cur = '';
    let lIdx = 0;
    for (const w of words) {
      const allowed = getLineMaxW(lIdx, tryLines);
      const test = cur ? (cur + w) : w;
      if (measure(test) > allowed && cur) {
        lines.push(cur);
        cur = w;
        lIdx++;
      } else {
        cur = test;
      }
    }
    if (cur) lines.push(cur);
    best = lines;
    if (lines.length * lineH <= safeH) break;
  }
  return best;
}

function fitTextInBubble(text, width, height, fontFamily, fontSizeMultiplier = 1.0) {
  const minFs = 12;
  const maxFs = Math.max(minFs, Math.round(Math.min(height * 0.5, width * 0.5, 48) * fontSizeMultiplier));
  let best = { fontSize: minFs, lines: [text], lineHeight: minFs * 1.3 };

  for (let fs = maxFs; fs >= minFs; fs--) {
    const lines = wrapTextAdaptive(text, width * 0.88, height * 0.88, fs, fontFamily, true);
    const lineH = fs * 1.30;
    const totalH = lines.length * lineH;
    if (totalH <= height * 0.90) {
      return { fontSize: fs, lines, lineHeight: lineH };
    }
    if (fs === minFs) {
      best = { fontSize: fs, lines, lineHeight: lineH };
    }
  }
  return best;
}

  const textColor = textStyle?.textColor || '#000000';
  const textOutline = textStyle?.textOutline || '#FFFFFF';
  const fontFamily = textStyle?.fontFamily || "'Itim', 'FC Subject', sans-serif";
  const fontSizeMultiplier = textStyle?.fontSizeMultiplier || 1.0;

  // 2. Render Thai text bubbles on top of the clean canvas
  bubbles.forEach((b) => {
    const displayedText = SuperKPolicy.extensionDisplayedText(b);
    if (b.deleted || !displayedText || !b.box || b.box.length !== 4) return;
    
    let rawYmin = Math.min(b.box[0], b.box[2]);
    let rawXmin = Math.min(b.box[1], b.box[3]);
    let rawYmax = Math.max(b.box[0], b.box[2]);
    let rawXmax = Math.max(b.box[1], b.box[3]);

    const origW = ((rawXmax - rawXmin) / 1000) * renderW;
    const origH = ((rawYmax - rawYmin) / 1000) * renderH;
    const origX = offsetX + (rawXmin / 1000) * renderW;
    const origY = offsetY + (rawYmin / 1000) * renderH;

    let fit = fitTextInBubble(displayedText, origW, origH, fontFamily, fontSizeMultiplier);
    const snapshot = b.layoutSnapshot || b.layoutAdjustment?.layoutSnapshot;
    const hasSnapshot = snapshot?.text === displayedText && snapshot.fontFamily === fontFamily && snapshot.globalMult === fontSizeMultiplier && snapshot.bubbleMult === (b.fontSizeMultiplier || 1) && (!b.layoutAdjustment || (b.layoutAdjustment.bw === snapshot.frameWidthPx && b.layoutAdjustment.bh === snapshot.frameHeightPx)) && Array.isArray(snapshot.lines) && snapshot.lines.length > 0 && snapshot.lines.length <= 400 && snapshot.lines.every(line => typeof line === 'string') && snapshot.lines.join('').replace(/\s/g, '') === displayedText.replace(/\s/g, '') &&
      [snapshot.fontSizePx,snapshot.lineHeightPx,snapshot.frameWidthPx,snapshot.frameHeightPx].every(n=>typeof n==='number' && Number.isFinite(n) && n>0);
    if (hasSnapshot) {
      const scale = origW / snapshot.frameWidthPx;
      fit = {fontSize:snapshot.fontSizePx * scale,lineHeight:snapshot.lineHeightPx * scale,lines:snapshot.lines};
    }
    const bubbleProfile = b.styleProfile || {};
    const category = bubbleProfile.category || b.styleCategory || 'dialogue';
    const isManual = bubbleProfile.ownershipMode === 'manual' || bubbleProfile.source === 'manual';
    const shadowOff = isManual && bubbleProfile.manualShadowMode === 'off';

    const isMonoPage = bubbleProfile.isMonochromePage ?? pageStyle?.isMonochromePage ?? false;
    const monoConfidence = bubbleProfile.monochromeConfidence ?? pageStyle?.monochromeConfidence ?? 0;
    const isMonochromeAuto =
      isMonoPage === true &&
      monoConfidence >= 0.85 &&
      !isManual;

    // Keep cached, direct and server overlays aligned with the Web policy.
    const bubbleTextColor = isMonochromeAuto ? '#000000' : (bubbleProfile.fill || textColor);
    const hasOutline = !isMonochromeAuto && bubbleProfile.hasOutline !== false;
    const bubbleTextOutline = bubbleProfile.outline || textOutline;
    const outlineRatio = Math.max(0.04, Math.min(0.30, bubbleProfile.outlineWidthRatio || 0.09));

    const outlineShadows = hasOutline ? [
      `-${outlineRatio}em -${outlineRatio}em 0 ${bubbleTextOutline}`,
      `${outlineRatio}em -${outlineRatio}em 0 ${bubbleTextOutline}`,
      `-${outlineRatio}em ${outlineRatio}em 0 ${bubbleTextOutline}`,
      `${outlineRatio}em ${outlineRatio}em 0 ${bubbleTextOutline}`,
      `0 ${outlineRatio}em 0 ${bubbleTextOutline}`,
      `0 -${outlineRatio}em 0 ${bubbleTextOutline}`,
      `${outlineRatio}em 0 0 ${bubbleTextOutline}`,
      `-${outlineRatio}em 0 0 ${bubbleTextOutline}`,
    ] : [];

    const standardShadow = (shadowOff || isMonochromeAuto)
      ? null
      : '0.08em 0.08em 0.15em rgba(30, 30, 30, 0.80)';

    const textShadowValue = [...outlineShadows, standardShadow].filter(Boolean).join(', ') || 'none';

    const bubbleEl = document.createElement('div');
    bubbleEl.className = 'superk-text-bubble';
    bubbleEl.style.cssText = `
      position: absolute;
      top: ${origY.toFixed(0)}px;
      left: ${origX.toFixed(0)}px;
      width: ${origW.toFixed(0)}px;
      min-height: ${origH.toFixed(0)}px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      pointer-events: auto;
      cursor: move;
      color: ${bubbleTextColor};
      font-family: ${hasSnapshot ? snapshot.fontFamily : fontFamily};
      font-weight: bold;
      font-size: ${fit.fontSize}px;
      line-height: ${fit.lineHeight}px;
      padding: 0;
      background: transparent;
      border: none;
      box-shadow: none;
      text-shadow: ${textShadowValue};
      user-select: text;
      word-break: break-word;
      z-index: 2;
    `;

    bubbleEl.textContent = fit.lines.join('\n');
    bubbleEl.contentEditable = "false";
    if (!hasSnapshot || !document.fonts?.check?.(`bold ${fit.fontSize}px ${snapshot.fontFamily}`)) bubbleEl.dataset.sourceSizeStatus = "fallback";
    else bubbleEl.dataset.sourceSizeStatus = "resolved-layout";
    if (bubbleEl.dataset.sourceSizeStatus === "fallback") bubbleEl.title = "ยังเทียบขนาดต้นฉบับไม่ได้ — เปิดใน SuperK เพื่อตรวจรูปแบบตัวอักษร";

    // Enable simple drag to reposition
    makeDraggable(bubbleEl);

    layer.appendChild(bubbleEl);
  });

  // Floating Control Bar
  const controlBar = document.createElement('div');
  controlBar.className = 'superk-control-bar';
  controlBar.innerHTML = `
    <button class="superk-ctrl-btn" data-action="toggle" title="สลับดูภาพต้นฉบับ">✨ ดูต้นฉบับ</button>
    <button class="superk-ctrl-btn" data-action="open-editor" title="เปิดแก้ไขใน SuperK Editor">✏️ เปิดใน SuperK</button>
    <button class="superk-ctrl-btn" data-action="retranslate" title="แปลภาพนี้ใหม่">🔄 แปลใหม่</button>
    <button class="superk-ctrl-btn" data-action="delete" title="ลบคำแปลออกจากเครื่อง">🗑️ ลบคำแปล</button>
    <button class="superk-ctrl-btn" data-action="close" title="ปิด overlay">✕</button>
  `;

  let showingOriginal = false;

  controlBar.querySelector('[data-action="toggle"]').onclick = (e) => {
    e.stopPropagation();
    showingOriginal = !showingOriginal;
    const btn = controlBar.querySelector('[data-action="toggle"]');
    layer.style.visibility = showingOriginal ? 'hidden' : 'visible';
    if (showingOriginal) {
      btn.innerHTML = '👁️ ดูคำแปล';
    } else {
      btn.innerHTML = '✨ ดูต้นฉบับ';
    }
  };

  const openEditorBtn = controlBar.querySelector('[data-action="open-editor"]');
  if (openEditorBtn) {
    openEditorBtn.onclick = (e) => {
      e.stopPropagation();
      if (typeof chrome !== 'undefined' && chrome?.runtime?.sendMessage) {
        chrome.runtime.sendMessage({
          action: 'OPEN_EDITOR',
          payload: {
            ...evidence,
            pageUrl: imageUrl,
            cleanUrl: cleanImageBase64,
            bubbles,
            originUrl: window.location.href,
          }
        });
      }
    };
  }

  const storageKey = `superk_trans_${imageUrl}`;
  controlBar.querySelector('[data-action="retranslate"]').onclick = (e) => {
    e.stopPropagation();
    if (typeof chrome !== 'undefined' && chrome?.runtime?.sendMessage) {
      chrome.runtime.sendMessage({ action: 'RETRY_TRANSLATE', imageUrl });
    }
  };

  controlBar.querySelector('[data-action="delete"]').onclick = (e) => {
    e.stopPropagation();
    if (typeof chrome !== 'undefined' && chrome?.storage?.local?.remove) {
      chrome.storage.local.remove(storageKey).catch(() => {});
    }
    cleanup();
  };

  // Persist translation overlay in extension local storage
  if (typeof chrome !== 'undefined' && chrome?.storage?.local?.set) {
    chrome.storage.local.set({
      [storageKey]: {
        ...evidence,
        imageUrl,
        bubbles,
        cleanMode,
        cleanImageBase64,
        textStyle,
        pageStyle,
        timestamp: Date.now(),
      },
    }).catch(() => {});
  }

  const baseW = imgRect.width;
  const baseH = imgRect.height;
  const updatePosition = () => {
    const newRect = img.getBoundingClientRect();
    const win = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : null);
    const newScrollX = win ? (win.scrollX || win.pageXOffset || 0) : 0;
    const newScrollY = win ? (win.scrollY || win.pageYOffset || 0) : 0;
    overlayContainer.style.top = `${newRect.top + newScrollY}px`;
    overlayContainer.style.left = `${newRect.left + newScrollX}px`;
    overlayContainer.style.width = `${newRect.width}px`;
    overlayContainer.style.height = `${newRect.height}px`;

    if (baseW > 0 && baseH > 0) {
      const scaleX = newRect.width / baseW;
      const scaleY = newRect.height / baseH;
      layer.style.transform = `scale(${scaleX}, ${scaleY})`;
    }
  };

  // Track only the target image: a ResizeObserver for box changes and a
  // narrow attribute observer for src swaps — never the whole document
  // (a document-wide observer forced layout on every host-page mutation).
  const resizeObserver = new ResizeObserver(updatePosition);
  resizeObserver.observe(img);
  const srcObserver = new MutationObserver(updatePosition);
  srcObserver.observe(img, { attributes: true, attributeFilter: ['src'] });
  window.addEventListener('scroll', updatePosition, { passive: true });

  const cleanup = () => {
    window.removeEventListener('resize', updatePosition);
    window.removeEventListener('scroll', updatePosition);
    resizeObserver.disconnect();
    srcObserver.disconnect();
    overlayContainer.remove();
    activeOverlays.delete(imageUrl);
  };
  activeOverlays.set(imageUrl, cleanup);

  controlBar.querySelector('[data-action="close"]').onclick = (e) => {
    e.stopPropagation();
    cleanup();
  };

  overlayContainer.appendChild(controlBar);

  // Append to document.body (not the image wrapper) for reliable positioning
  document.body.appendChild(overlayContainer);

  window.addEventListener('resize', updatePosition);

  // Overlays live as long as the reader stays on this page — cleanup happens
  // on SPA navigation, manual close, or tab close, never on a fixed timer.

  // Success Toast
  showToast(img, "✨ แปลเสร็จเรียบร้อย!");
}

// 3. Handle Translation Error
function handleTranslationError(imageUrl, errorMsg) {
  const img = findImageElement(imageUrl);
  if (!img) return;

  removeExistingBadge(img);
  removeExistingLoadingScrim(imageUrl);
  showErrorBadge(img, errorMsg);
}

// 4. Handle Published Update from SuperK Editor
function handlePublishedUpdate(pageUrl, bubbles, cleanUrl, textStyle, evidence) {
  if (!globalThis.SuperKPolicy || SuperKPolicy.inspectExtensionOutput({...evidence,bubbles},true).status !== "eligible") { handleTranslationError(pageUrl,"Publication needs current review"); return; }
  const img = findImageElement(pageUrl);
  if (!img) return;

  const cleanup = activeOverlays.get(pageUrl);
  if (cleanup) cleanup();

  handleTranslationSuccess(
    pageUrl,
    bubbles,
    "inpainting",
    cleanUrl || null,
    textStyle, undefined, evidence
  );

  showToast(img, "✨ อัปเดตคำแปลจาก SuperK เรียบร้อยแล้ว!");
}

// Helper: Show Error Badge
function showErrorBadge(img, message) {
  const badge = document.createElement('div');
  badge.className = 'superk-status-badge superk-error';
  badge.id = `superk-badge-${hashCode(img.src)}`;

  const text = document.createElement('span');
  text.textContent = `❌ ${message}`;

  const actions = document.createElement('div');
  actions.className = 'superk-error-actions';
  actions.style.cssText = 'display:inline-flex;gap:6px;align-items:center;margin-left:8px;';

  const retryBtn = document.createElement('button');
  retryBtn.className = 'superk-retry-btn';
  retryBtn.textContent = '🔄 ลองใหม่';
  retryBtn.setAttribute('data-action', 'retry');
  retryBtn.style.cssText = 'background:#f59e0b;color:#fff;border:none;padding:2px 8px;border-radius:4px;cursor:pointer;font-size:12px;';
  retryBtn.addEventListener('click', () => {
    badge.remove();
    if (typeof chrome !== 'undefined' && chrome?.runtime?.sendMessage) {
      chrome.runtime.sendMessage({ action: 'RETRY_TRANSLATE', imageUrl: img.src });
    }
  });

  const close = document.createElement('button');
  close.textContent = '✕';
  close.setAttribute('aria-label', 'ปิดข้อความแจ้งเตือน');
  close.addEventListener('click', () => badge.remove());

  actions.append(retryBtn, close);
  badge.append(text, actions);
  positionBadgeOverImage(img, badge);
  setTimeout(() => badge.remove(), 10000);
}

// Helper: Show Toast
function showToast(img, message) {
  const toast = document.createElement('div');
  toast.className = 'superk-status-badge superk-success';
  toast.innerText = message;
  positionBadgeOverImage(img, toast);
  setTimeout(() => toast.remove(), 3000);
}

// Helper: Position Badge over target image attached cleanly to document.body
function positionBadgeOverImage(img, badge) {
  const imgRect = img.getBoundingClientRect();
  const win = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : null);
  const scrollX = win ? (win.scrollX || win.pageXOffset || 0) : 0;
  const scrollY = win ? (win.scrollY || win.pageYOffset || 0) : 0;

  badge.style.position = 'absolute';
  badge.style.top = `${imgRect.top + scrollY + 12}px`;
  badge.style.left = `${imgRect.left + scrollX + imgRect.width / 2}px`;
  badge.style.transform = 'translateX(-50%)';
  badge.style.zIndex = '100000';
  document.body.appendChild(badge);
}

function removeExistingBadge(img) {
  const badges = document.querySelectorAll('.superk-status-badge');
  badges.forEach(el => el.remove());
}

// Simple Drag logic for text bubbles
function makeDraggable(el) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  el.onmousedown = dragMouseDown;

  function dragMouseDown(e) {
    if (document.activeElement === el && el.isContentEditable) return; // allow text selection
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    el.style.top = (el.offsetTop - pos2) + "px";
    el.style.left = (el.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

function hashCode(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

function restoreSavedTranslations() {
  if (typeof chrome === 'undefined' || !chrome?.storage?.local?.get) return;
  const images = Array.from(document.querySelectorAll('img'));
  images.forEach(img => {
    const src = img.src || img.currentSrc;
    if (!src) return;
    const key = `superk_trans_${src}`;
    chrome.storage.local.get(key).then(res => {
      const saved = res?.[key];
      if (saved && saved.bubbles && !activeOverlays.has(src)) {
        handleTranslationSuccess(
          saved.imageUrl,
          saved.bubbles,
          saved.cleanMode,
          saved.cleanImageBase64,
          saved.textStyle,
          saved.pageStyle, saved
        );
      }
    }).catch(() => {});
  });
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(restoreSavedTranslations, 300));
  } else {
    setTimeout(restoreSavedTranslations, 100);
  }
}

// SPA navigation watcher: overlays belong to the page they were translated
// for. When the reading site swaps pages without a reload, clean the old
// page's overlays and restore any saved translations for the new one.
let superkActivePageUrl = window.location.href;
setInterval(() => {
  if (window.location.href === superkActivePageUrl) return;
  superkActivePageUrl = window.location.href;
  for (const cleanup of Array.from(activeOverlays.values())) {
    cleanup();
  }
  setTimeout(restoreSavedTranslations, 100);
}, 1500);

})();
